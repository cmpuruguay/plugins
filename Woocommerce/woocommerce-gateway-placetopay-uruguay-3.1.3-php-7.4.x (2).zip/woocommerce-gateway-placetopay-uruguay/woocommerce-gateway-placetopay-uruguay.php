<?php
/**
 * Plugin Name: WooCommerce Placetopay Gateway
 * Plugin URI: https://checkout.placetopay.uy
 * Description: Adds Placetopay Payment Gateway to WooCommerce e-commerce plugin
 *
 * Author: Placetopay
 * Author URI: https://www.evertecinc.com/pasarela-de-pagos-e-commerce/
 * Developer: Placetopay
 * Version: 3.1.3
 *
 * @package \PlacetopayUruguay\PaymentMethod\WC_Gateway_PlacetopayUruguay
 *
 * @author Soporte <soporte@placetopay.com>
 * @copyright (c) 2013-2026 Evertec PlacetoPay S.A.S.
 * @version 3.1.3
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

if ( is_admin() ) {
    add_filter( 'all_plugins', 'dynamic_plugin_name_placetopay_uruguay' );
}

/**
 * @param array $plugins
 * @return array
 */
function dynamic_plugin_name_placetopay_uruguay( $plugins ) {
    $plugin_file = plugin_basename( __FILE__ );

    if ( isset( $plugins[ $plugin_file ] ) ) {
        $client = \PlacetopayUruguay\PaymentMethod\CountryConfig::CLIENT;

        $plugins[ $plugin_file ]['Name'] = 'WooCommerce '. $client . ' Gateway';
        $plugins[ $plugin_file ]['Description'] = 'Adds ' . $client  . ' Payment Gateway to WooCommerce e-commerce plugin';
        $plugins[ $plugin_file ]['Author'] = $client;
    }

    return $plugins;
}

/**
 * IMPORTANTE: WordPress 6.7+ requiere que se cargue en 'init' o después
 */
function load_placetopay_uruguay_textdomain() {
    load_plugin_textdomain('woocommerce-gateway-translations', false, dirname(plugin_basename(__FILE__)) . '/languages/');
}

add_action('init', 'load_placetopay_uruguay_textdomain', 1);

/**
 * @return \PlacetopayUruguay\PaymentMethod\WC_Gateway_PlacetopayUruguay
 */
function wc_gateway_placetopay_uruguay()
{
    add_filter('woocommerce_locate_template', 'wooAddonPluginTemplate_placetopay_uruguay', 201, 3);

    /**
     * @param $template
     * @param $templateName
     * @param $templatePath
     * @return string
     */
    function wooAddonPluginTemplate_placetopay_uruguay($template, $templateName, $templatePath)
    {
        global $woocommerce;

        $_template = $template;

        if (!$templatePath) {
            $templatePath = $woocommerce->template_url;
        }

        $pluginPath = untrailingslashit(plugin_dir_path(__FILE__)) . '/woocommerce/';

        $template = locate_template([
            $templatePath . $templateName,
            $templateName
        ]);

        if (!$template && file_exists($pluginPath . $templateName)) {
            $template = $pluginPath . $templateName;
        }

        if (!$template) {
            $template = $_template;
        }

        return $template;
    }

    require_once(__DIR__ . '/src/helpers.php');
    require_once(__DIR__ . '/vendor/autoload.php');

    return \PlacetopayUruguay\PaymentMethod\WC_Gateway_PlacetopayUruguay::getInstance(
        \PlacetopayUruguay\PaymentMethod\GatewayMethodPlacetopayUruguay::VERSION,
        __FILE__
    );
}

add_action('plugins_loaded', 'wc_gateway_placetopay_uruguay', 0);
