<?php

use PlacetopayUruguay\PaymentMethod\Constants\Country;
use PlacetopayUruguay\PaymentMethod\CountryConfig;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

/**
 * @var \PlacetopayUruguay\PaymentMethod\GatewayMethodPlacetopayUruguay $this
 */

return CountryConfig::getFields($this);

