<?php

namespace PlacetopayUruguay\PaymentMethod\Constants;

/**
 * Interface Environment
 * @package PlacetoPay\GatewayMethodPlacetopayUruguay\Constants
 */
interface Environment
{
    const PROD = 'prod';

    const DEV = 'dev';

    const TEST = 'test';

    const CUSTOM = 'custom';
}