<?php

namespace PlacetopayUruguay\PaymentMethod\Constants;

use PlacetopayUruguay\PaymentMethod\Countries\BelizeCountryConfig;
use PlacetopayUruguay\PaymentMethod\Countries\ChileCountryConfig;
use PlacetopayUruguay\PaymentMethod\Countries\ColombiaCountryConfig;
use PlacetopayUruguay\PaymentMethod\Countries\EcuadorCountryConfig;
use PlacetopayUruguay\PaymentMethod\Countries\HondurasCountryConfig;
use PlacetopayUruguay\PaymentMethod\Countries\UruguayCountryConfig;
use PlacetopayUruguay\PaymentMethod\CountryConfig;

interface Country
{
    const EC = 'EC';
    const UY = 'UY';
    const CO = 'CO';
}
